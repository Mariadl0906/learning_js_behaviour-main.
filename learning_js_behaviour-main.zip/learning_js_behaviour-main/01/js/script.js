"use strict";

const websiteBody = document.body;

websiteBody.style = "background: yellow";

